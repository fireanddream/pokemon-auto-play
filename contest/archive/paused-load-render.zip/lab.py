"""Temporary five-frame comparison; all captures preserve the paused endpoint."""

from __future__ import annotations

import argparse
from collections import Counter
import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import struct
import sys
import time

from PIL import Image, ImageGrab

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0, str(ROOT))

from host.controller import Controller
from host.emulator import DeSmuME
from host.savestates import StateSlots


def write_result(name, value):
    (WORK / f"{name}.json").write_text(json.dumps(value, indent=2), encoding="utf-8")


def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def image_facts(image):
    rgb = image.convert("RGB")
    colors = Counter({color: count for count, color in rgb.getcolors(rgb.width * rgb.height)})
    color, count = colors.most_common(1)[0]
    total = rgb.width * rgb.height
    return {"size": list(rgb.size), "distinct_colors": len(colors),
            "dominant_rgb": list(color), "dominant_fraction": round(count / total, 6),
            "colored_fraction": round(sum(n for color, n in colors.items()
                if max(color) - min(color) > 8) / total, 6)}


def window_capture(controller, name):
    user32 = controller.USER32
    user32.SetProcessDPIAware()
    data = controller.session()
    user32.ShowWindow(data["window"], 9)
    user32.SetForegroundWindow(data["window"])
    user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, ctypes.c_int, wintypes.UINT]
    was_topmost = bool(user32.GetWindowLongPtrW(data["window"], -20) & 0x8)
    assert user32.SetWindowPos(data["window"], -1, 0, 0, 0, 0, 0x13)
    time.sleep(0.1)
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    rect = wintypes.RECT()
    if not user32.GetWindowRect(data["window"], ctypes.byref(rect)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        image = ImageGrab.grab(bbox=(rect.left, rect.top, rect.right, rect.bottom), all_screens=True)
    finally:
        if not was_topmost:
            user32.SetWindowPos(data["window"], -2, 0, 0, 0, 0, 0x13)
    path = WORK / f"{name}-window.png"
    image.save(path)
    return {"path": str(path), "source": "visible_window_screen_capture", "raised_for_capture": True,
            **image_facts(image)}


def gd_image(path):
    raw = path.read_bytes()
    magic, width, height = struct.unpack_from(">HHH", raw)
    assert magic == 65534 and raw[6] == 1 and len(raw) == 11 + width * height * 4
    channels = Image.frombytes("RGBA", (width, height), raw[11:]).split()
    return Image.merge("RGB", channels[1:])


def capture(controller, name):
    assert controller.paused(controller.session())
    window = window_capture(controller, name)
    observation = controller.checkpoint_command("capture", [name])
    image = gd_image(Path(observation["image"]))
    png = WORK / f"{name}-framebuffer.png"
    image.save(png)
    result = {"frame": observation["frame"], "after_callbacks": observation["after_callbacks"],
              "game_code": observation["game_code"], "emulator_paused": observation["emulator_paused"],
              "window": window, "framebuffer": {"path": str(png), "source": observation["source"],
              **image_facts(image)}}
    write_result(name, result)
    return result


def attach(controller):
    started = time.time_ns()
    controller.load_lua(WORK / "observe.lua")
    while True:
        status = read_json(controller.STATUS)
        if (status.get("bridge") == "frame-advance-probe"
                and controller.STATUS.stat().st_mtime_ns >= started):
            break
        time.sleep(0.02)
    controller.set_pause(True)


def baseline(controller, name):
    assert not controller.session().get("lua_script")
    bare = window_capture(controller, f"{name}-bare")
    attach(controller)
    result = capture(controller, name)
    result["bare_window"] = bare
    result["pid"] = controller.session()["pid"]
    write_result(name, result)
    return result


def fresh_slot_five(controller):
    previous = controller.session()
    slots = StateSlots(controller)
    slots.validate_header(slots.path(5), 5)
    controller.set_pause(True)
    assert controller.USER32.PostMessageW(previous["window"], 0x10, 0, 0)
    while controller.emulator_process_ids() or controller.emulator_window_process_ids():
        time.sleep(0.05)
    current = controller.launch(Path(previous["rom"]))
    controller.set_pause(True)
    item = slots.menu("Load", 5)
    controller.send(current["window"], 0x111, item["id"])
    assert controller.paused(current)
    return current


def internal(controller):
    before = capture(controller, "internal-before")
    response = controller.bridge_command("advance", ["5"], None)
    cached_path = WORK / "internal-callback-framebuffer.png"
    controller.screenshot(cached_path)
    cached = Image.open(cached_path).convert("RGB")
    after = capture(controller, "internal-after")
    result = {"method": "existing_input_bridge_advance_5", "pid": controller.session()["pid"],
              "before": before, "after": after, "frame_delta": after["frame"] - before["frame"],
              "command": {key: response.get(key) for key in (
                  "command_start_frame", "command_end_frame", "frame", "screen_frame", "command_done",
                  "stop_reason", "error", "emulator_paused")},
              "callback_capture": {"path": str(cached_path), **image_facts(cached)}}
    write_result("internal-result", result)
    assert result["frame_delta"] == 5 and response["command_done"] and not response["error"]
    return result


def native(controller):
    fresh_slot_five(controller)
    before = baseline(controller, "native-before")
    settings = DeSmuME(controller).configuration()
    assert settings.getint("Hotkeys", "FrameAdvance", fallback=78) == 78
    assert settings.getint("Hotkeys", "FrameAdvance MOD", fallback=0) == 0
    data = controller.session()
    key = 78 | (0x8 << 16)
    steps = []
    for index in range(1, 6):
        assert controller.paused(data)
        expected = before["frame"] + index
        try:
            assert controller.USER32.PostMessageW(data["window"], 0x432, key, 1)
            while True:
                if not controller.USER32.IsWindow(data["window"]):
                    raise RuntimeError("The emulator closed during a native frame step")
                progress = read_json(WORK / "frame-progress.json")
                if progress.get("frame", -1) >= expected:
                    assert progress["frame"] == expected, "A native N press advanced more than one frame"
                    break
                time.sleep(0.005)
        finally:
            assert controller.USER32.PostMessageW(data["window"], 0x433, key, 0xC0000001)
        time.sleep(0.05)
        while not controller.paused(data):
            time.sleep(0.01)
        step = capture(controller, f"native-step-{index}")
        assert step["frame"] == expected
        steps.append(step)
        print(json.dumps({"press": index, "frame": step["frame"], "paused": True,
                          "framebuffer": step["framebuffer"]}), flush=True)
    result = {"method": "native_N_hotkey_down_and_up_five_times", "pid": data["pid"],
              "before": before, "steps": steps, "after": steps[-1],
              "frame_delta": steps[-1]["frame"] - before["frame"]}
    write_result("native-result", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("baseline", "internal", "native"))
    args = parser.parse_args()
    controller = Controller()
    try:
        if args.action == "baseline":
            result = baseline(controller, "initial")
        elif args.action == "internal":
            result = internal(controller)
        else:
            result = native(controller)
        print(json.dumps(result, indent=2))
    finally:
        controller.set_pause(True)


if __name__ == "__main__":
    main()
