-- Temporary passive frame observations around the existing input bridge.
local source = debug.getinfo(1, "S").source:sub(2):gsub("\\", "/")
local work = assert(source:match("^(.*)/"))
local root = work .. "/../.."
local bridge_io = dofile(root .. "/lua/bridge_io.lua")
local json = dofile(root .. "/lua/json.lua")
local mailbox = bridge_io.new(root .. "/tmp", "checkpoint-")
local previous = mailbox:previous_id()
local callbacks = 0
local observer = {name = "frame-advance-probe", commands = {}}

local function write(path, value)
    local stream = assert(io.open(path, "wb"))
    assert(stream:write(value))
    assert(stream:close())
end

function observer.snapshot(frame)
    return {frame = frame, game_code = emu.gamecode(), after_callbacks = callbacks}
end

function observer.update(frame)
    callbacks = callbacks + 1
    write(work .. "/frame-progress.json", json.encode(observer.snapshot(frame)))
end

function observer.attach(api)
    bridge_io.apply_buttons(nil)
    stylus.set({touch = false})
    write(work .. "/frame-progress.json", json.encode(observer.snapshot(emu.framecount())))
    local function poll()
        local parts = mailbox:read_command(previous)
        if not parts then return end
        previous = parts[1]
        local ok, result = pcall(function()
            assert(parts[2] == "capture", "Expected a paused capture request")
            local label = assert(parts[3])
            assert(label:match("^[a-z0-9-]+$"), "Invalid capture label")
            local frame = emu.framecount()
            local image = work .. "/" .. label .. ".gd"
            write(image, gui.gdscreenshot())
            assert(emu.framecount() == frame, "A paused capture changed the frame")
            local captured = observer.snapshot(frame)
            captured.menu_end_supported = type(emu.registermenuend) == "function"
            local prior = emu.registermenustart(nil)
            captured.previous_menu_callback_type = type(prior)
            emu.registermenustart(prior or poll)
            captured.image = image
            captured.source = "fresh_paused_gui_gdscreenshot"
            return captured
        end)
        if not ok then result = {error = tostring(result), frame = emu.framecount()} end
        result.command_id, result.command_done = previous, true
        mailbox:publish(result)
    end
    emu.registermenustart(poll)
end

assert(loadfile(root .. "/lua/input_bridge.lua"))(observer)
